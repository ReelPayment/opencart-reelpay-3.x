<?php

require_once(DIR_SYSTEM . 'library/reelpay/ReelpayClient.php');
require_once(DIR_SYSTEM . 'library/reelpay/ReelpayCover.php');

class ControllerExtensionPaymentReelpay extends Controller
{
    private $error = array();

    public function index()
    {
        $this->load->language('extension/payment/reelpay');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
        $this->load->model('localisation/order_status');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('payment_reelpay', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
        }

        $data['action'] = $this->url->link('extension/payment/reelpay', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/payment/reelpay', 'user_token=' . $this->session->data['user_token'], true)
        );

        $fields = array(
            'payment_reelpay_status',
            'payment_reelpay_appid',
            'payment_reelpay_appkey',
            'payment_reelpay_sort_order',
            'payment_reelpay_order_status_id',
            'payment_reelpay_paid_status_id',
            'payment_reelpay_time_out_status_id',
            'payment_reelpay_fail_status_id',
            );

        $data['white_label_options'] = array('false' => 'Disabled', 'true' => 'Enabled');

        foreach ($fields as $field) {
            if (isset($this->request->post[$field])) {
                $data[$field] = $this->request->post[$field];
            } else {
                $data[$field] = $this->config->get($field);
            }
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/payment/reelpay', $data));
    }

    protected function validate()
    {
        $this->load->language('extension/payment/reelpay');
        if (!class_exists('ReelpayClient')) {
            $this->error['warning'] = $this->language->get('error_composer');
        }
        if (!isset($this->request->post['payment_reelpay_appkey'])) {
            $this->error['warning'] = $this->language->get('error_reelpay_appkey');
        }
        if (!isset($this->request->post['payment_reelpay_appid'])) {
            $this->error['warning'] = $this->language->get('error_reelpay_appid');
        }
        $reelpay = new ReelpayClient($this->request->post['payment_reelpay_appkey'], $this->request->post['payment_reelpay_appid']);
        $res = $reelpay->Currency([]);
        if (empty($res) || !isset($res["code"]) || $res["code"] != 200) {
            $this->error['warning'] = $this->language->get('error_reelpay_wrong_key');
        }
        return !$this->error;
    }

    public function install()
    {
        $this->load->model('extension/payment/reelpay');

        $this->model_extension_payment_reelpay->install();
    }

    public function uninstall(){}
}
