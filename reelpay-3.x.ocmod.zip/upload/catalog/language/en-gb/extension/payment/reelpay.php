<?php

$_['text_title'] = 'ReelPay';
$_['button_confirm'] = 'Pay with ReelPay';
$_['button_currency_confirm'] = 'Pay %s with ReelPay';
$_['pay_with_text'] = 'Pay with: ';
$_['text_checkout'] = 'Checkout';
