<?php

class ModelExtensionPaymentReelPay extends Model
{
    public function getMethod($address, $total)
    {
        $this->load->language('extension/payment/reelpay');

        $method_data = array(
            'code' => 'ReelPay',
            'title' => $this->language->get('text_title'),
            'terms' => '',
            'sort_order' => $this->config->get('payment_reelpay_sort_order')
        );
        return $method_data;
    }
}
